// Initialize Firebase
var config = {
  apiKey: "AIzaSyAJVzMmVKirPbg3EGQ8rGZa6C9nR-XU020",
  authDomain: "promote-energy.firebaseapp.com",
  databaseURL: "https://promote-energy.firebaseio.com",
  projectId: "promote-energy",
  storageBucket: "promote-energy.appspot.com",
  messagingSenderId: "768376713146"
};
firebase.initializeApp(config);